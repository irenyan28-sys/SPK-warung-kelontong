import React from 'react';
import { 
  Sliders, 
  HelpCircle, 
  RotateCcw, 
  Percent, 
  Check, 
  AlertTriangle,
  Scale
} from 'lucide-react';
import { Criterion } from '../types/saw';

interface CriteriaManagerViewProps {
  criteria: Criterion[];
  onUpdateCriterion: (id: string, updates: Partial<Criterion>) => void;
  onNormalizeWeights: () => void;
  onResetCriteria: () => void;
}

export const CriteriaManagerView: React.FC<CriteriaManagerViewProps> = ({
  criteria,
  onUpdateCriterion,
  onNormalizeWeights,
  onResetCriteria,
}) => {
  const totalWeight = criteria.reduce((sum, c) => sum + (c.weight || 0), 0);
  const isValidWeight = Math.abs(totalWeight - 100) < 0.01;

  return (
    <div className="space-y-6 pb-12">
      {/* Header Info */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
            <span>Konfigurasi Sistem</span>
            <span aria-hidden="true">·</span>
            <span>Kriteria &amp; Bobot Penilaian</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Parameter Penilaian Kriteria
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Kelola bobot persentase, sifat kriteria (Benefit / Cost), serta batas nilai pembagi.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onNormalizeWeights}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg border border-indigo-200 transition-colors cursor-pointer"
          >
            <Percent className="w-3.5 h-3.5" />
            <span>Normalisasikan ke 100%</span>
          </button>
          <button
            onClick={onResetCriteria}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-200 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Kriteria Default</span>
          </button>
        </div>
      </div>

      {/* Weight Summary Banner */}
      <div className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs ${
        isValidWeight 
          ? 'bg-emerald-50 border-emerald-200 text-emerald-900' 
          : 'bg-amber-50 border-amber-300 text-amber-900'
      }`}>
        <div className="flex items-center gap-2.5">
          {isValidWeight ? (
            <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
              ✓
            </div>
          ) : (
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
          )}
          <div>
            <span className="font-bold">
              Total Bobot Saat Ini: <span className="font-mono text-sm">{totalWeight.toFixed(1)}%</span>
            </span>
            <span className="block text-[11px] opacity-90 mt-0.5">
              {isValidWeight 
                ? 'Total bobot telah tepat 100%. Komputasi preferensi berjalan presisi.' 
                : 'Total bobot belum 100%. Klik tombol "Normalisasikan ke 100%" agar proporsional.'}
            </span>
          </div>
        </div>

        {!isValidWeight && (
          <button
            onClick={onNormalizeWeights}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-lg shadow-xs transition-colors cursor-pointer shrink-0"
          >
            Seimbangkan Otomatis
          </button>
        )}
      </div>

      {/* Criteria Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {criteria.map((c) => (
          <div key={c.id} className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-slate-900 text-base">{c.fullName}</span>
                <span className="font-mono text-sm font-bold text-indigo-600">{c.weight}%</span>
              </div>

              <p className="text-xs text-slate-500 mb-4 min-h-[32px]">
                {c.description}
              </p>

              {/* Slider weight */}
              <div className="space-y-1.5 mb-4">
                <div className="flex justify-between text-[11px] text-slate-500 font-medium">
                  <span>Bobot Kriteria</span>
                  <span className="font-mono">{c.weight}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="1"
                  value={c.weight}
                  onChange={(e) => onUpdateCriterion(c.id, { weight: Number(e.target.value) })}
                  className="w-full accent-indigo-600 cursor-pointer h-2 bg-slate-200 rounded-lg appearance-none"
                />
              </div>

              {/* Type Toggle: Benefit vs Cost */}
              <div className="mb-4">
                <span className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                  Sifat Kriteria:
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={() => onUpdateCriterion(c.id, { type: 'benefit' })}
                    className={`py-1.5 px-3 rounded-lg border font-medium transition-colors cursor-pointer text-center ${
                      c.type === 'benefit'
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-bold'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Benefit (Maksimal)
                  </button>
                  <button
                    onClick={() => onUpdateCriterion(c.id, { type: 'cost' })}
                    className={`py-1.5 px-3 rounded-lg border font-medium transition-colors cursor-pointer text-center ${
                      c.type === 'cost'
                        ? 'bg-rose-50 border-rose-300 text-rose-800 font-bold'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Cost (Minimal)
                  </button>
                </div>
              </div>
            </div>

            {/* Custom Divisor setting */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-600">Nilai Pembagi Referensi:</span>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={0.1}
                  max={100}
                  step={0.5}
                  value={c.customDivisor}
                  onChange={(e) => onUpdateCriterion(c.id, { customDivisor: parseFloat(e.target.value) || 1 })}
                  className="w-14 text-center font-mono font-bold text-xs bg-slate-50 border border-slate-300 rounded px-1 py-1 focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
