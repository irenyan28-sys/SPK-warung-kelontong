import React, { useState } from 'react';
import { X, Plus, Store } from 'lucide-react';
import { Criterion, Alternative } from '../types/saw';

interface AddAlternativeModalProps {
  isOpen: boolean;
  onClose: () => void;
  criteria: Criterion[];
  existingAlternativesCount: number;
  onAdd: (newAlt: Alternative) => void;
}

export const AddAlternativeModal: React.FC<AddAlternativeModalProps> = ({
  isOpen,
  onClose,
  criteria,
  existingAlternativesCount,
  onAdd,
}) => {
  const nextCodeNum = existingAlternativesCount + 1;
  const [name, setName] = useState('');
  const [note, setNote] = useState('');
  const [values, setValues] = useState<Record<string, number>>(() => {
    const initial: Record<string, number> = {};
    criteria.forEach((c) => {
      initial[c.id] = 4;
    });
    return initial;
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newAlt: Alternative = {
      id: `A_${Date.now()}`,
      code: `V${nextCodeNum}`,
      name: name.trim(),
      values,
      note: note.trim() || 'Pemasok baru',
    };

    onAdd(newAlt);
    setName('');
    setNote('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Store className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">Tambah Pemasok Baru</h3>
              <p className="text-xs text-slate-500">Alternatif baru akan langsung terhitung di dashboard</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nama Toko / Supplier
            </label>
            <input
              type="text"
              required
              placeholder="Contoh: Toko Berkah Jaya"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
            />
          </div>

          <div className="space-y-3 pt-2">
            <span className="block text-xs font-semibold text-slate-700">
              Penilaian Kriteria (Skala 1 - 5)
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {criteria.map((c) => (
                <div key={c.id} className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-slate-800">{c.fullName}</span>
                    <span className="font-mono font-bold text-indigo-600">
                      {values[c.id] ?? 4}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="5"
                    step="1"
                    value={values[c.id] ?? 4}
                    onChange={(e) => setValues({ ...values, [c.id]: Number(e.target.value) })}
                    className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                    <span>1 (Min)</span>
                    <span className="capitalize">{c.type}</span>
                    <span>5 (Maks)</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Catatan / Lokasi (Opsional)
            </label>
            <input
              type="text"
              placeholder="Catatan tambahan mengenai pemasok ini..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Simpan &amp; Hitung Otomatis</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
