import React, { useState } from 'react';
import { 
  Plus, 
  Minus,
  Trash2, 
  Info, 
  Zap,
  Sparkles,
  RotateCcw,
  TrendingUp,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { Criterion, Alternative, DivisorMode, CalculationResult } from '../types/saw';
import { formatNumber } from '../utils/sawCalculator';

interface DecisionMatrixTableProps {
  criteria: Criterion[];
  alternatives: Alternative[];
  divisors: Record<string, number>;
  divisorMode: DivisorMode;
  calcResult?: CalculationResult;
  lastEdit?: {
    altName: string;
    critName: string;
    oldVal: number;
    newVal: number;
    timestamp: string;
  } | null;
  onUpdateValue: (altId: string, critId: string, val: number) => void;
  onUpdateCustomDivisor: (critId: string, val: number) => void;
  onAddAlternative: () => void;
  onDeleteAlternative: (altId: string) => void;
  onResetData: () => void;
}

export const DecisionMatrixTable: React.FC<DecisionMatrixTableProps> = ({
  criteria,
  alternatives,
  divisors,
  divisorMode,
  calcResult,
  lastEdit,
  onUpdateValue,
  onUpdateCustomDivisor,
  onAddAlternative,
  onDeleteAlternative,
  onResetData,
}) => {
  const [activeCell, setActiveCell] = useState<{ altId: string; critId: string } | null>(null);

  // Quick edit step handlers
  const handleStep = (altId: string, critId: string, currentVal: number, delta: number) => {
    const nextVal = Math.max(1, Math.min(10, currentVal + delta));
    onUpdateValue(altId, critId, nextVal);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Info */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
            <span>Langkah 1</span>
            <span aria-hidden="true">·</span>
            <span>Matriks Keputusan (X) &amp; Perhitungan Otomatis</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Data Nilai Alternatif (Bisa Diedit Langsung)
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Ubah nilai sel dengan tombol <strong>[-]</strong> / <strong>[+]</strong> atau ketik langsung. Seluruh rumus, pembagi, normalisasi, dan ranking <strong>otomatis dihitung ulang saat itu juga</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onAddAlternative}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah Alternatif Toko</span>
          </button>
          <button
            onClick={onResetData}
            title="Kembalikan data ke spreadsheet awal"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-200 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset Nilai Asli</span>
          </button>
        </div>
      </div>

      {/* Quick Test Edit Playground Strip */}
      <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-200 text-xs text-indigo-950 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-indigo-600 shrink-0" />
          <span className="font-semibold">Coba Fitur Perhitungan Otomatis Sekali Klik:</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              const dewi = alternatives.find(a => a.name.includes('Dewi'));
              if (dewi) onUpdateValue(dewi.id, 'C2', 5);
            }}
            className="px-2.5 py-1 bg-white hover:bg-indigo-100/80 text-indigo-800 border border-indigo-200 rounded-md font-medium cursor-pointer transition-colors"
          >
            Uji: Kwalitas Toko Dewi = 5
          </button>
          <button
            onClick={() => {
              const pinem = alternatives.find(a => a.name.includes('Pinem'));
              if (pinem) onUpdateValue(pinem.id, 'C3', 1);
            }}
            className="px-2.5 py-1 bg-white hover:bg-indigo-100/80 text-indigo-800 border border-indigo-200 rounded-md font-medium cursor-pointer transition-colors"
          >
            Uji: Jarak Toko Pinem = 1
          </button>
          <button
            onClick={() => {
              const meicin = alternatives.find(a => a.name.includes('Meicin'));
              if (meicin) onUpdateValue(meicin.id, 'C4', 5);
            }}
            className="px-2.5 py-1 bg-white hover:bg-indigo-100/80 text-indigo-800 border border-indigo-200 rounded-md font-medium cursor-pointer transition-colors"
          >
            Uji: Kelengkapan Meicin = 5
          </button>
          <button
            onClick={onResetData}
            className="px-2.5 py-1 bg-slate-200/80 hover:bg-slate-300 text-slate-700 rounded-md font-medium cursor-pointer transition-colors"
          >
            Reset Awal
          </button>
        </div>
      </div>

      {/* Main Table Styled faithfully like the Spreadsheet */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              {/* Row 1: Bobot */}
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-700">
                <th className="py-2.5 px-4 font-bold border-r border-slate-200 w-48">
                  Bobot →
                </th>
                {criteria.map((c) => (
                  <th key={c.id} className="py-2.5 px-4 font-bold text-center border-r border-slate-200">
                    <span className="font-mono text-sm text-indigo-700">{c.weight}%</span>
                  </th>
                ))}
                <th className="py-2.5 px-4 text-center font-bold text-slate-400 w-24">
                  Aksi
                </th>
              </tr>

              {/* Row 2: Kriteria Header (matches the green header in spreadsheet) */}
              <tr className="bg-emerald-100/90 text-emerald-950 border-b border-emerald-300">
                <th className="py-3 px-4 font-extrabold border-r border-emerald-300">
                  Alternatif
                </th>
                {criteria.map((c) => (
                  <th key={c.id} className="py-3 px-4 font-extrabold text-center border-r border-emerald-300">
                    <div className="text-xs">{c.fullName}</div>
                    <div className="text-[10px] font-normal text-emerald-800 opacity-90 capitalize">
                      {c.type === 'benefit' ? 'Benefit' : 'Cost'}
                    </div>
                  </th>
                ))}
                <th className="py-3 px-4 text-center font-semibold text-emerald-800">
                  Opsi
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-200">
              {alternatives.map((alt) => {
                const rankingItem = calcResult?.rankings.find(r => r.alternative.id === alt.id);
                const isWinner = rankingItem?.rank === 1;

                return (
                  <tr key={alt.id} className={`hover:bg-slate-50/80 transition-colors ${isWinner ? 'bg-emerald-50/20' : ''}`}>
                    <td className="py-2.5 px-4 font-bold text-slate-900 border-r border-slate-200 bg-slate-50/30">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          {isWinner && <span className="text-[10px] bg-emerald-600 text-white font-bold px-1 rounded">#1</span>}
                          <span>{alt.name}</span>
                        </div>
                        <span className="text-[11px] font-mono text-slate-400 font-normal">
                          {alt.code}
                        </span>
                      </div>
                    </td>

                    {criteria.map((c) => {
                      const val = alt.values[c.id] ?? 0;
                      const isEditing = activeCell?.altId === alt.id && activeCell?.critId === c.id;
                      const isLastEdited = lastEdit?.altName === alt.name && lastEdit?.critName.includes(c.name);

                      return (
                        <td 
                          key={c.id} 
                          className={`py-2 px-2 text-center border-r border-slate-200 transition-colors ${
                            isEditing ? 'bg-indigo-50/70 ring-1 ring-inset ring-indigo-400' : isLastEdited ? 'bg-amber-50/60' : ''
                          }`}
                        >
                          <div className="inline-flex items-center justify-center gap-1 bg-white border border-slate-200 rounded-md p-0.5 shadow-2xs">
                            {/* Decrement Button */}
                            <button
                              type="button"
                              onClick={() => handleStep(alt.id, c.id, val, -1)}
                              disabled={val <= 1}
                              title="Kurangi nilai 1 (Otomatis hitung)"
                              className="w-5 h-5 flex items-center justify-center rounded text-slate-500 hover:text-slate-900 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                            >
                              <Minus className="w-3 h-3" />
                            </button>

                            {/* Direct Number Input */}
                            <input
                              type="number"
                              min={1}
                              max={10}
                              step={1}
                              value={val}
                              onFocus={() => setActiveCell({ altId: alt.id, critId: c.id })}
                              onBlur={() => setActiveCell(null)}
                              onChange={(e) => {
                                const num = parseFloat(e.target.value);
                                onUpdateValue(alt.id, c.id, isNaN(num) ? 1 : num);
                              }}
                              className="w-8 text-center font-mono font-bold text-xs bg-transparent focus:outline-hidden"
                            />

                            {/* Increment Button */}
                            <button
                              type="button"
                              onClick={() => handleStep(alt.id, c.id, val, 1)}
                              disabled={val >= 10}
                              title="Tambah nilai 1 (Otomatis hitung)"
                              className="w-5 h-5 flex items-center justify-center rounded text-slate-500 hover:text-slate-900 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </td>
                      );
                    })}

                    <td className="py-2 px-3 text-center">
                      {alternatives.length > 2 && (
                        <button
                          onClick={() => onDeleteAlternative(alt.id)}
                          title={`Hapus ${alt.name}`}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5 mx-auto" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}

              {/* Row: Jenis (Benefit / Cost) - orange bar like Excel */}
              <tr className="bg-amber-100 text-amber-950 font-bold border-t-2 border-b border-amber-300">
                <td className="py-2.5 px-4 font-bold border-r border-amber-300">
                  Jenis →
                </td>
                {criteria.map((c) => (
                  <td key={c.id} className="py-2.5 px-4 text-center border-r border-amber-300 capitalize font-mono text-xs">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      c.type === 'benefit' ? 'bg-amber-200/80 text-amber-900' : 'bg-rose-200/80 text-rose-900'
                    }`}>
                      {c.type === 'benefit' ? 'Benefit' : 'Cost'}
                    </span>
                  </td>
                ))}
                <td className="py-2.5 px-4 text-center text-amber-700 text-[10px]">
                  Tipe
                </td>
              </tr>

              {/* Row: Nilai Pembagi (Max for Benefit, Min for Cost) */}
              <tr className="bg-slate-100 font-bold text-slate-800">
                <td className="py-3 px-4 font-bold border-r border-slate-300">
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1">
                      <span>Nilai Pembagi →</span>
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Otomatis terhitung" />
                    </div>
                    <span className="text-[10px] text-slate-500 font-normal">
                      {divisorMode === 'sheet' ? '(Otomatis Adaptif / Sheet)' : '(Dinamis Max/Min Otomatis)'}
                    </span>
                  </div>
                </td>
                {criteria.map((c) => {
                  const currentDivisor = divisors[c.id] ?? c.customDivisor;

                  return (
                    <td key={c.id} className="py-3 px-4 text-center border-r border-slate-300 font-mono text-sm">
                      <div className="inline-flex items-center justify-center gap-1 font-bold text-indigo-700 font-mono">
                        <span>{formatNumber(currentDivisor, 2)}</span>
                        {c.type === 'benefit' ? (
                          <span className="text-[10px] text-slate-400 font-normal">(Max)</span>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-normal">(Min)</span>
                        )}
                      </div>
                    </td>
                  );
                })}
                <td className="py-3 px-4 text-center text-[10px] text-slate-500 font-normal">
                  Pembagi
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Live Calculation Feedback Footer */}
        {lastEdit && (
          <div className="p-3.5 bg-emerald-50/80 border-t border-emerald-200 text-xs text-emerald-950 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                <strong>Perhitungan Otomatis Selesai ({lastEdit.timestamp}):</strong>{' '}
                Nilai <strong>{lastEdit.altName}</strong> pada <strong>{lastEdit.critName}</strong> berhasil diubah dari{' '}
                <span className="font-mono font-bold line-through text-slate-500">{lastEdit.oldVal}</span> ke{' '}
                <span className="font-mono font-bold text-emerald-700 bg-white px-1.5 py-0.5 rounded border border-emerald-300">{lastEdit.newVal}</span>.
              </span>
            </div>

            {calcResult?.bestAlternative && (
              <div className="text-xs font-semibold text-emerald-900 bg-white px-2.5 py-1 rounded-md border border-emerald-200 shrink-0">
                Pemenang Saat Ini: <strong>{calcResult.bestAlternative.alternative.name}</strong> ({formatNumber(calcResult.bestAlternative.score, 4)})
              </div>
            )}
          </div>
        )}

        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-indigo-600 shrink-0" />
            <span>
              <strong>Petunjuk:</strong> Nilai 1-5 (1 = Sangat Rendah/Jauh, 5 = Sangat Baik/Dekat). Klik tombol <strong>+</strong> atau <strong>-</strong> pada sel mana pun untuk melihat skor akhir langsung berubah seketika.
            </span>
          </div>
          <div className="text-slate-500 font-medium">
            Kriteria Jarak (Cost): semakin kecil nilainya, semakin besar skor preferensinya.
          </div>
        </div>
      </div>
    </div>
  );
};
