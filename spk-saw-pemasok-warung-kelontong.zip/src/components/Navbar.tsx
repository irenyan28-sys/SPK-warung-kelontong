import React from 'react';
import { 
  BarChart3, 
  Table2, 
  SlidersHorizontal, 
  Sparkles, 
  FileSpreadsheet, 
  RotateCcw,
  CheckCircle2,
  GitCompare
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenExcelRef: () => void;
  onResetData: () => void;
  autoCalculate: boolean;
  toggleAutoCalculate: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenExcelRef,
  onResetData,
  autoCalculate,
  toggleAutoCalculate,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'decision', label: 'Matriks Keputusan (X)', icon: Table2 },
    { id: 'normalization', label: 'Normalisasi (R)', icon: Table2 },
    { id: 'weighted', label: 'Nilai Akhir (V)', icon: Sparkles },
    { id: 'criteria', label: 'Kriteria & Bobot', icon: SlidersHorizontal },
    { id: 'simulation', label: 'Simulasi Sensitivitas', icon: GitCompare },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-16">
          {/* Zone 1: Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-lg shadow-sm">
              S
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap block leading-tight">
                SPK SAW Warung
              </span>
              <span className="text-[11px] text-slate-500 font-medium whitespace-nowrap block">
                Sistem Pemasok Barang
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1 overflow-x-auto py-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-700'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Actions */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Auto calc status pill toggle */}
            <button
              onClick={toggleAutoCalculate}
              title={autoCalculate ? 'Perhitungan otomatis aktif saat data diedit' : 'Perhitungan manual'}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                autoCalculate
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                  : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Auto-Kalkulasi:</span>
              <span className="font-semibold">{autoCalculate ? 'Aktif' : 'Nonaktif'}</span>
            </button>

            {/* View Original Excel Button */}
            <button
              onClick={onOpenExcelRef}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-200 transition-colors cursor-pointer whitespace-nowrap"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden md:inline">Tabel Excel Asli</span>
            </button>

            {/* Reset Data Button */}
            <button
              onClick={onResetData}
              title="Reset ke data awal spreadsheet"
              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg border border-transparent hover:border-slate-200 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile & Tablet Nav Row */}
        <div className="flex xl:hidden items-center gap-1 overflow-x-auto pb-2 pt-1 border-t border-slate-100 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap transition-colors shrink-0 ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-700 font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-3 h-3 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
