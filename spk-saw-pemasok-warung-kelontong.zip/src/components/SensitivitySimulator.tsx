import React, { useState } from 'react';
import { GitCompare, Sliders, ArrowRight, TrendingUp, TrendingDown, Minus, RotateCcw } from 'lucide-react';
import { Criterion, Alternative, DivisorMode } from '../types/saw';
import { calculateSAW, formatNumber } from '../utils/sawCalculator';

interface SensitivitySimulatorProps {
  criteria: Criterion[];
  alternatives: Alternative[];
  divisorMode: DivisorMode;
  currentRankings: Array<{ rank: number; alternative: Alternative; score: number }>;
}

export const SensitivitySimulator: React.FC<SensitivitySimulatorProps> = ({
  criteria,
  alternatives,
  divisorMode,
  currentRankings,
}) => {
  const [simCriteria, setSimCriteria] = useState<Criterion[]>(() => JSON.parse(JSON.stringify(criteria)));

  const handleSimWeightChange = (id: string, weight: number) => {
    setSimCriteria(prev => prev.map(c => c.id === id ? { ...c, weight } : c));
  };

  const handleResetSim = () => {
    setSimCriteria(JSON.parse(JSON.stringify(criteria)));
  };

  // Run simulation calculation
  const simResult = calculateSAW(simCriteria, alternatives, divisorMode);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
            <span>Analisis Lanjutan</span>
            <span aria-hidden="true">·</span>
            <span>Simulasi Sensitivitas Keputusan</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Uji Sensitivitas Perubahan Bobot (What-If Analysis)
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Simulasikan pergeseran bobot kriteria untuk melihat ketahanan (robustness) peringkat toko pemasok.
          </p>
        </div>

        <button
          onClick={handleResetSim}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-200 transition-colors cursor-pointer shrink-0"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset ke Bobot Aktif</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sliders for Simulation Weights */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-indigo-600" />
            <span>Atur Bobot Simulasi</span>
          </h3>

          <div className="space-y-4">
            {simCriteria.map((c) => (
              <div key={c.id} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-800">{c.fullName}</span>
                  <span className="font-mono font-bold text-indigo-600">{c.weight}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  value={c.weight}
                  onChange={(e) => handleSimWeightChange(c.id, Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer h-2 bg-slate-200 rounded-lg appearance-none"
                />
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-slate-100 text-xs text-slate-500">
            *Hasil preferensi otomatis disesuaikan secara proporsional.
          </div>
        </div>

        {/* Side-by-side Comparison Leaderboard */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
            <GitCompare className="w-4 h-4 text-emerald-600" />
            <span>Perbandingan Peringkat: Kondisi Riil vs Hasil Simulasi</span>
          </h3>

          <div className="space-y-3">
            {simResult.rankings.map((simItem) => {
              const currentItem = currentRankings.find(r => r.alternative.id === simItem.alternative.id);
              const curRank = currentItem ? currentItem.rank : 0;
              const rankDiff = curRank - simItem.rank; // positive = promoted, negative = demoted

              return (
                <div 
                  key={simItem.alternative.id}
                  className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                      #{simItem.rank}
                    </span>

                    <div>
                      <div className="font-bold text-sm text-slate-900">
                        {simItem.alternative.name}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Skor Simulasi: <span className="font-mono font-bold text-slate-800">{formatNumber(simItem.score, 4)}</span> (Awal: {formatNumber(currentItem?.score || 0, 4)})
                      </div>
                    </div>
                  </div>

                  {/* Rank Movement Indicator */}
                  <div className="flex items-center gap-2 shrink-0">
                    {rankDiff > 0 ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-bold text-xs bg-emerald-100 px-2.5 py-1 rounded-md">
                        <TrendingUp className="w-3.5 h-3.5" />
                        <span>Naik +{rankDiff}</span>
                      </span>
                    ) : rankDiff < 0 ? (
                      <span className="inline-flex items-center gap-1 text-rose-700 font-bold text-xs bg-rose-100 px-2.5 py-1 rounded-md">
                        <TrendingDown className="w-3.5 h-3.5" />
                        <span>Turun {rankDiff}</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-slate-500 font-medium text-xs bg-slate-200 px-2.5 py-1 rounded-md">
                        <Minus className="w-3 h-3" />
                        <span>Tetap</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-950">
            <strong>Kesimpulan Simulasi:</strong> Pemenang simulasi adalah <span className="font-bold text-emerald-900">{simResult.bestAlternative?.alternative.name}</span> dengan nilai akhir preferensi <span className="font-mono font-bold">{formatNumber(simResult.bestAlternative?.score || 0, 4)}</span>.
          </div>
        </div>
      </div>
    </div>
  );
};
