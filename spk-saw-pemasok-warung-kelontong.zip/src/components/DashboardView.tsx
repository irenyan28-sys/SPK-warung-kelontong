import React from 'react';
import { 
  Trophy, 
  TrendingUp, 
  Store, 
  Scale, 
  ArrowRight, 
  ArrowUpRight, 
  Sparkles, 
  HelpCircle,
  Percent,
  Sliders,
  ChevronRight,
  Plus,
  Minus,
  Zap,
  CheckCircle2
} from 'lucide-react';
import { Criterion, Alternative, CalculationResult, DivisorMode } from '../types/saw';
import { formatNumber } from '../utils/sawCalculator';

interface DashboardViewProps {
  criteria: Criterion[];
  alternatives: Alternative[];
  calcResult: CalculationResult;
  divisorMode: DivisorMode;
  lastEdit?: {
    altName: string;
    critName: string;
    oldVal: number;
    newVal: number;
    timestamp: string;
  } | null;
  onSelectTab: (tabId: string) => void;
  onUpdateAlternativeValue: (altId: string, critId: string, val: number) => void;
  onOpenExcelRef: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  criteria,
  alternatives,
  calcResult,
  divisorMode,
  lastEdit,
  onSelectTab,
  onUpdateAlternativeValue,
  onOpenExcelRef,
}) => {
  const { rankings, bestAlternative } = calcResult;
  const runnerUp = rankings.length > 1 ? rankings[1] : null;
  const scoreGap = runnerUp && bestAlternative ? (bestAlternative.score - runnerUp.score) : 0;

  // Max possible score reference (typically 1.0)
  const maxScore = Math.max(...rankings.map(r => r.score), 1);

  // Criteria colors for charts
  const criteriaColors: Record<string, { bg: string; text: string; fill: string }> = {
    C1: { bg: 'bg-blue-500', text: 'text-blue-700', fill: '#3b82f6' },
    C2: { bg: 'bg-emerald-500', text: 'text-emerald-700', fill: '#10b981' },
    C3: { bg: 'bg-amber-500', text: 'text-amber-700', fill: '#f59e0b' },
    C4: { bg: 'bg-purple-500', text: 'text-purple-700', fill: '#a855f7' },
    C5: { bg: 'bg-rose-500', text: 'text-rose-700', fill: '#f43f5e' },
  };

  const handleStep = (altId: string, critId: string, currentVal: number, delta: number) => {
    const nextVal = Math.max(1, Math.min(10, currentVal + delta));
    onUpdateAlternativeValue(altId, critId, nextVal);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Title & Case Study Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-2">
              <span>Sistem Pendukung Keputusan</span>
              <span aria-hidden="true">·</span>
              <span>Metode Simple Additive Weighting (SAW)</span>
            </div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-slate-900 tracking-tight leading-snug">
              Analisis Penentuan Pemasok Barang untuk Warung Kelontong
            </h1>
            <p className="mt-2 text-sm text-slate-600 leading-relaxed">
              Model komputasi multi-kriteria untuk memilih supplier terbaik berdasarkan efisiensi harga, kualitas produk, kedekatan jarak pengantaran, kelengkapan barang, serta mutu pelayanan dengan kalkulasi real-time.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={onOpenExcelRef}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg border border-indigo-200 transition-colors cursor-pointer"
            >
              <span>Verifikasi Tabel Excel Asli</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Big Verdict Banner - Exactly matches the Excel formula cell */}
        {bestAlternative && (
          <div className="mt-6 p-4 sm:p-5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-950 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Trophy className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 block">
                  Keputusan Akhir Terpilih (Kalkulasi Real-Time)
                </span>
                <span className="text-base sm:text-lg font-extrabold text-emerald-950 tracking-tight block">
                  HASIL TERBESAR ADALAH {bestAlternative.alternative.name.toUpperCase()} DENGAN NILAI = {formatNumber(bestAlternative.score, 4)}
                </span>
              </div>
            </div>

            <div className="text-xs text-emerald-800 bg-emerald-100/80 px-3 py-1.5 rounded-md border border-emerald-300/60 font-medium">
              Peringkat 1 dari {alternatives.length} Pemasok ({bestAlternative.code})
            </div>
          </div>
        )}

        {/* Last Edit Live Notification Pill */}
        {lastEdit && (
          <div className="mt-3 p-3 bg-indigo-50 border border-indigo-200 rounded-lg text-xs text-indigo-950 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>
                <strong>Perhitungan Otomatis:</strong> Nilai <strong>{lastEdit.altName}</strong> pada <strong>{lastEdit.critName}</strong> baru saja diubah ke <span className="font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-indigo-200">{lastEdit.newVal}</span>. Nilai akhir dan ranking langsung diperbarui seketika!
              </span>
            </div>
            <span className="text-[11px] font-mono text-indigo-700 shrink-0">
              {lastEdit.timestamp}
            </span>
          </div>
        )}
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Pemenang */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Pemasok Rekomendasi</span>
            <Trophy className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-xl font-bold text-slate-900 truncate">
            {bestAlternative ? bestAlternative.alternative.name : '-'}
          </div>
          <div className="mt-1 text-xs text-slate-500 flex items-center gap-1.5">
            <span className="font-semibold text-indigo-600">{bestAlternative?.code}</span>
            <span>·</span>
            <span>Skor: <span className="font-mono font-semibold text-slate-900">{formatNumber(bestAlternative?.score || 0, 4)}</span></span>
          </div>
        </div>

        {/* Card 2: Runner Up & Gap */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Selisih dgn Posisi 2</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-xl font-bold font-mono tabular-nums text-slate-900">
            +{formatNumber(scoreGap, 4)}
          </div>
          <div className="mt-1 text-xs text-slate-500 truncate">
            Runner-up: <span className="font-medium text-slate-800">{runnerUp?.alternative.name || '-'}</span> ({formatNumber(runnerUp?.score || 0, 4)})
          </div>
        </div>

        {/* Card 3: Total Alternatif */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Pemasok Dievaluasi</span>
            <Store className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
            {alternatives.length} Toko
          </div>
          <div className="mt-1 text-xs text-slate-500">
            Perhitungan: <span className="font-semibold text-emerald-700">Otomatis Terhubung</span>
          </div>
        </div>

        {/* Card 4: Kriteria Dominan */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Bobot Terbesar</span>
            <Scale className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-xl font-bold text-slate-900">
            Harga &amp; Kelengkapan
          </div>
          <div className="mt-1 text-xs text-slate-500">
            Masing-masing memiliki bobot <span className="font-semibold text-indigo-600">30%</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Real-Time Ranking Visualizer + Criteria Contribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column (7 cols): Real-Time Ranking Leaderboard */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Peringkat Nilai Akhir Preferensi (V)
                </h2>
                <p className="text-xs text-slate-500">
                  Dihitung otomatis seketika saat nilai diedit
                </p>
              </div>
              <button
                onClick={() => onSelectTab('weighted')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                Lihat Detail <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Ranking Bars */}
            <div className="space-y-4 my-6">
              {rankings.map((item) => {
                const isWinner = item.rank === 1;
                const percentage = Math.min(100, (item.score / maxScore) * 100);

                return (
                  <div 
                    key={item.alternative.id}
                    className={`p-3.5 rounded-lg border transition-all ${
                      isWinner 
                        ? 'bg-emerald-50/60 border-emerald-300 ring-1 ring-emerald-200' 
                        : 'bg-slate-50/70 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between text-sm mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                          isWinner ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
                        }`}>
                          {item.rank}
                        </span>
                        <span className="font-bold text-slate-900">
                          {item.alternative.name}
                        </span>
                        <span className="text-xs font-mono text-slate-500">
                          ({item.alternative.code})
                        </span>
                        {isWinner && (
                          <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                            Rekomendasi
                          </span>
                        )}
                      </div>

                      <div className="text-right">
                        <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                          {formatNumber(item.score, 4)}
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-300 ${
                          isWinner ? 'bg-emerald-500' : 'bg-indigo-600'
                        }`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>

                    {/* Criteria Sub-Breakdown pills */}
                    <div className="flex items-center gap-2 mt-2 pt-1 border-t border-slate-100 text-[11px] text-slate-500 overflow-x-auto">
                      {criteria.map((c) => {
                        const weightedVal = item.weightedValues[c.id] || 0;
                        return (
                          <span key={c.id} className="whitespace-nowrap">
                            <span className="font-medium text-slate-700">{c.name}:</span>{' '}
                            <span className="font-mono">{formatNumber(weightedVal, 3)}</span>
                          </span>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Rumus: <span className="font-mono">V_i = ∑ (w_j × r_ij)</span></span>
            <span>Total Bobot: 100%</span>
          </div>
        </div>

        {/* Right Column (5 cols): Criteria Weight Distribution & Stacked Composition */}
        <div className="lg:col-span-5 space-y-6">
          {/* Bobot Kriteria Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Struktur Bobot Kriteria
                </h2>
                <p className="text-xs text-slate-500">
                  Toleransi dan prioritas pengambilan keputusan
                </p>
              </div>
              <button
                onClick={() => onSelectTab('criteria')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                Ubah Bobot <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {criteria.map((c) => {
                const color = criteriaColors[c.id] || { bg: 'bg-indigo-500', text: 'text-indigo-700' };
                return (
                  <div key={c.id} className="flex items-center justify-between text-xs p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                    <div className="flex items-center gap-2.5">
                      <span className={`w-3 h-3 rounded-full ${color.bg}`} />
                      <div>
                        <span className="font-bold text-slate-800">{c.fullName}</span>
                        <span className="text-[11px] text-slate-500 ml-1.5">
                          ({c.type === 'benefit' ? 'Benefit (Maksimal)' : 'Cost (Minimal)'})
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900">{c.weight}%</span>
                      <span className="text-slate-400 font-mono text-[11px]">
                        (÷{calcResult.divisors[c.id] ?? c.customDivisor})
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Real-Time Data Tweak (Interactive playground) */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-indigo-600" />
                  <span>Uji Edit Cepat: Nilai Jarak (C3)</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Klik [-] atau [+] untuk menyaksikan skor dan peringkat berubah seketika
                </p>
              </div>
            </div>

            <div className="space-y-2.5">
              {alternatives.map((alt) => (
                <div key={alt.id} className="flex items-center justify-between gap-3 text-xs p-2 rounded-md bg-slate-50 border border-slate-100">
                  <span className="font-medium text-slate-800 truncate w-36">
                    {alt.name}
                  </span>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleStep(alt.id, 'C3', alt.values['C3'] ?? 1, -1)}
                      className="w-5 h-5 flex items-center justify-center rounded bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 cursor-pointer font-bold"
                      title="Kurangi jarak (otomatis hitung)"
                    >
                      -
                    </button>
                    <span className="w-7 text-center font-mono font-bold text-xs bg-white border border-slate-200 rounded py-0.5">
                      {alt.values['C3'] ?? 1}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleStep(alt.id, 'C3', alt.values['C3'] ?? 1, 1)}
                      className="w-5 h-5 flex items-center justify-center rounded bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 cursor-pointer font-bold"
                      title="Tambah jarak (otomatis hitung)"
                    >
                      +
                    </button>
                    <span className="text-[11px] text-slate-500 font-mono ml-1">
                      v={formatNumber(calcResult.finalScores[alt.id] || 0, 3)}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 text-center">
              <button
                onClick={() => onSelectTab('decision')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 inline-flex items-center gap-1 cursor-pointer"
              >
                Buka Matriks Keputusan Penuh untuk Edit Semua Sel <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Decision Table Quick Overview Strip with Inline Stepper Editing */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Matriks Nilai &amp; Hasil Akhir (Dapat Diedit Langsung di Sini)
            </h2>
            <p className="text-xs text-slate-500">
              Gunakan tombol [-] / [+] pada setiap sel nilai toko di bawah ini untuk melihat perhitungannya secara otomatis!
            </p>
          </div>
          <button
            onClick={() => onSelectTab('decision')}
            className="text-xs font-semibold px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer shrink-0"
          >
            Buka Halaman Matriks X
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-200 text-slate-700">
                <th className="py-2.5 px-3 font-bold">Alternatif</th>
                {criteria.map((c) => (
                  <th key={c.id} className="py-2.5 px-3 font-semibold text-center">
                    <div>{c.fullName}</div>
                    <div className="text-[10px] text-slate-500">({c.weight}%)</div>
                  </th>
                ))}
                <th className="py-2.5 px-4 font-bold text-right bg-indigo-50/70 text-indigo-900">Nilai Akhir (V)</th>
                <th className="py-2.5 px-3 font-bold text-center bg-indigo-100/60 text-indigo-900">Peringkat</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {alternatives.map((alt) => {
                const rankingItem = rankings.find(r => r.alternative.id === alt.id);
                const rank = rankingItem ? rankingItem.rank : '-';
                const score = rankingItem ? rankingItem.score : 0;
                const isWinner = rank === 1;

                return (
                  <tr 
                    key={alt.id}
                    className={`hover:bg-slate-50 transition-colors ${isWinner ? 'bg-emerald-50/40 font-medium' : ''}`}
                  >
                    <td className="py-3 px-3 font-bold text-slate-900">
                      <div className="flex items-center gap-1.5">
                        {isWinner && (
                          <span className="text-[10px] bg-emerald-600 text-white px-1.5 py-0.5 rounded font-bold">
                            #1
                          </span>
                        )}
                        <span>{alt.name}</span>
                        <span className="text-[11px] font-mono text-slate-400">({alt.code})</span>
                      </div>
                    </td>

                    {criteria.map((c) => {
                      const val = alt.values[c.id] ?? 0;
                      return (
                        <td key={c.id} className="py-2 px-2 text-center">
                          <div className="inline-flex items-center justify-center gap-1 bg-white border border-slate-200 rounded px-1 py-0.5">
                            <button
                              type="button"
                              onClick={() => handleStep(alt.id, c.id, val, -1)}
                              disabled={val <= 1}
                              className="text-slate-400 hover:text-slate-900 w-4 h-4 flex items-center justify-center font-bold text-xs disabled:opacity-20 cursor-pointer"
                              title="Kurang 1"
                            >
                              -
                            </button>
                            <span className="w-5 text-center font-mono font-bold text-xs">
                              {val}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleStep(alt.id, c.id, val, 1)}
                              disabled={val >= 10}
                              className="text-slate-400 hover:text-slate-900 w-4 h-4 flex items-center justify-center font-bold text-xs disabled:opacity-20 cursor-pointer"
                              title="Tambah 1"
                            >
                              +
                            </button>
                          </div>
                        </td>
                      );
                    })}

                    <td className="py-3 px-4 text-right font-mono font-bold text-indigo-700 bg-indigo-50/30 tabular-nums">
                      {formatNumber(score, 4)}
                    </td>
                    <td className="py-3 px-3 text-center font-bold bg-indigo-50/50">
                      <span className={`inline-block w-6 h-6 leading-6 rounded-full text-xs ${
                        isWinner ? 'bg-emerald-600 text-white' : 'text-slate-700 bg-slate-200'
                      }`}>
                        {rank}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
