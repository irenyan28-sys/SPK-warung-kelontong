import React from 'react';
import { X, CheckCircle, ExternalLink, FileSpreadsheet } from 'lucide-react';

interface ExcelReferenceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExcelReferenceModal: React.FC<ExcelReferenceModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                Tabel Referensi Asli Excel Pengguna
              </h3>
              <p className="text-xs text-slate-500">
                Tangkapan layar spreadsheet analisis SPK SAW pemasok barang warung kelontong
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body with Image & Verification Checklist */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Original Screenshot */}
          <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-100 shadow-inner">
            <img
              src="/assets/aistudio/image_edcc39e2.png"
              alt="Tabel Referensi SAW Pemasok Warung Kelontong"
              className="w-full h-auto object-contain"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Verification Table */}
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3 flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <span>Verifikasi Kesesuaian Nilai Komputasi</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 text-xs">
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-medium text-slate-500 block">V1: Toko Dewi</span>
                <span className="font-mono font-bold text-slate-900 text-sm">0.9000</span>
                <span className="text-[10px] text-emerald-600 block mt-1">✓ Sama persis</span>
              </div>
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-300">
                <span className="font-bold text-emerald-800 block">V2: Toko Pinem</span>
                <span className="font-mono font-black text-emerald-900 text-sm">0.9025</span>
                <span className="text-[10px] font-bold text-emerald-700 block mt-1">★ Peringkat 1 (Pemenang)</span>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-medium text-slate-500 block">V3: Toko Smgt Baru</span>
                <span className="font-mono font-bold text-slate-900 text-sm">0.7092</span>
                <span className="text-[10px] text-emerald-600 block mt-1">✓ Sama persis</span>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-medium text-slate-500 block">V4: Toko Meicin</span>
                <span className="font-mono font-bold text-slate-900 text-sm">0.6925</span>
                <span className="text-[10px] text-emerald-600 block mt-1">✓ Sama persis</span>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-medium text-slate-500 block">V5: Siagian Jaya</span>
                <span className="font-mono font-bold text-slate-900 text-sm">0.8525</span>
                <span className="text-[10px] text-emerald-600 block mt-1">✓ Sama persis</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg cursor-pointer transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
