import React from 'react';
import { Zap, RefreshCw, Layers, Sliders, Check } from 'lucide-react';
import { DivisorMode } from '../types/saw';

interface AutoCalcBannerProps {
  autoCalculate: boolean;
  toggleAutoCalculate: () => void;
  divisorMode: DivisorMode;
  setDivisorMode: (mode: DivisorMode) => void;
  lastUpdated: string;
  recalcCount: number;
  onManualRecalculate: () => void;
}

export const AutoCalcBanner: React.FC<AutoCalcBannerProps> = ({
  autoCalculate,
  toggleAutoCalculate,
  divisorMode,
  setDivisorMode,
  lastUpdated,
  recalcCount,
  onManualRecalculate,
}) => {
  return (
    <div className="bg-slate-900 text-slate-100 border-b border-slate-800 px-4 py-2.5 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Left: Real-time Auto-Calculation Status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${autoCalculate ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${autoCalculate ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
            </span>
            <span className="font-semibold tracking-wide text-white">
              {autoCalculate ? 'Kalkulasi Otomatis Real-Time Aktif' : 'Kalkulasi Manual Aktif'}
            </span>
          </div>

          <span className="text-slate-400 hidden md:inline">·</span>

          <span className="text-slate-300 hidden md:inline">
            Tiap perubahan data/bobot langsung mengupdate matriks &amp; ranking seketika.
          </span>

          <span className="text-slate-400 hidden sm:inline">·</span>

          <span className="text-slate-400 font-mono tabular-nums">
            Sync #{recalcCount} ({lastUpdated})
          </span>
        </div>

        {/* Right: Controls & Divisor Mode Selection */}
        <div className="flex items-center gap-2">
          {/* Divisor mode toggle */}
          <div className="flex items-center bg-slate-800 rounded-md p-0.5 border border-slate-700">
            <button
              onClick={() => setDivisorMode('sheet')}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                divisorMode === 'sheet'
                  ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
              title="Menggunakan nilai pembagi sesuai tabel Excel: C1=4, C2=4, C3=1, C4=5, C5=4"
            >
              Mode Excel (C4=5)
            </button>
            <button
              onClick={() => setDivisorMode('dynamic')}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                divisorMode === 'dynamic'
                  ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
              title="Menggunakan nilai Max/Min dinamis langsung dari kumpulan data aktif"
            >
              Mode Dinamis (Max/Min)
            </button>
          </div>

          {!autoCalculate && (
            <button
              onClick={onManualRecalculate}
              className="flex items-center gap-1 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-md transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Hitung Ulang</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
