import React, { useState } from 'react';
import { HelpCircle, Calculator, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Criterion, Alternative, CalculationResult, DivisorMode } from '../types/saw';
import { formatNumber } from '../utils/sawCalculator';

interface NormalizationMatrixTableProps {
  criteria: Criterion[];
  alternatives: Alternative[];
  calcResult: CalculationResult;
  divisorMode: DivisorMode;
}

export const NormalizationMatrixTable: React.FC<NormalizationMatrixTableProps> = ({
  criteria,
  alternatives,
  calcResult,
  divisorMode,
}) => {
  const [selectedCell, setSelectedCell] = useState<{
    alt: Alternative;
    criterion: Criterion;
    rawVal: number;
    divisor: number;
    result: number;
  } | null>(null);

  const { normalizedMatrix, divisors } = calcResult;

  return (
    <div className="space-y-6 pb-12">
      {/* Header Info */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
            <span>Langkah 2</span>
            <span aria-hidden="true">·</span>
            <span>Matriks Normalisasi (R)</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Perhitungan Nilai Normalisasi Ternormalisasi
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Mentransformasikan seluruh skala nilai kriteria menjadi skala seragam antara 0 dan 1.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs bg-slate-50 border border-slate-200 p-2.5 rounded-lg text-slate-600">
          <Calculator className="w-4 h-4 text-indigo-600 shrink-0" />
          <span>Klik salah satu sel untuk melihat rincian rumus pembagian.</span>
        </div>
      </div>

      {/* Formula Explanatory Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Benefit Formula Card */}
        <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs">
          <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm mb-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span>Kriteria Benefit (C1, C2, C4, C5)</span>
          </div>
          <p className="text-emerald-800 leading-relaxed">
            Semakin besar nilai asli, semakin tinggi nilai normalisasinya.
          </p>
          <div className="mt-2 p-2 bg-white/90 border border-emerald-200 rounded font-mono text-emerald-950 font-semibold text-center">
            r_ij = x_ij / Max(x_j)
          </div>
        </div>

        {/* Cost Formula Card */}
        <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 text-xs">
          <div className="flex items-center gap-2 text-amber-900 font-bold text-sm mb-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span>Kriteria Cost (C3: Jarak)</span>
          </div>
          <p className="text-amber-800 leading-relaxed">
            Semakin kecil nilai asli, semakin tinggi nilai normalisasinya (jarak terdekat bernilai 1).
          </p>
          <div className="mt-2 p-2 bg-white/90 border border-amber-200 rounded font-mono text-amber-950 font-semibold text-center">
            r_ij = Min(x_j) / x_ij
          </div>
        </div>
      </div>

      {/* Main Normalization Matrix Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              {/* Green Header like spreadsheet */}
              <tr className="bg-emerald-100/90 text-emerald-950 border-b border-emerald-300">
                <th className="py-3 px-4 font-extrabold border-r border-emerald-300 w-52">
                  Matriks Normalisasi
                </th>
                {criteria.map((c) => (
                  <th key={c.id} className="py-3 px-4 font-extrabold text-center border-r border-emerald-300">
                    <div className="text-xs">{c.fullName}</div>
                    <div className="text-[10px] font-normal text-emerald-800 opacity-90">
                      (Pembagi: {divisors[c.id] ?? c.customDivisor})
                    </div>
                  </th>
                ))}
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-200">
              {alternatives.map((alt) => (
                <tr key={alt.id} className="hover:bg-indigo-50/30 transition-colors">
                  <td className="py-3 px-4 font-bold text-slate-900 border-r border-slate-200 bg-slate-50/40">
                    <div className="flex items-center justify-between">
                      <span>{alt.name}</span>
                      <span className="text-[11px] font-mono text-slate-400 font-normal">
                        {alt.code}
                      </span>
                    </div>
                  </td>

                  {criteria.map((c) => {
                    const normVal = normalizedMatrix[alt.id]?.[c.id] ?? 0;
                    const rawVal = alt.values[c.id] ?? 0;
                    const divisor = divisors[c.id] ?? c.customDivisor;
                    const isSelected = selectedCell?.alt.id === alt.id && selectedCell?.criterion.id === c.id;

                    return (
                      <td
                        key={c.id}
                        onClick={() => setSelectedCell({ alt, criterion: c, rawVal, divisor, result: normVal })}
                        className={`py-3 px-4 text-center font-mono border-r border-slate-200 tabular-nums cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-indigo-100 font-bold text-indigo-900 ring-2 ring-inset ring-indigo-500'
                            : 'hover:bg-slate-100 text-slate-800'
                        }`}
                        title="Klik untuk lihat rincian rumus sel ini"
                      >
                        <span className="font-semibold text-sm">
                          {formatNumber(normVal, 4)}
                        </span>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Selected Cell Formula Inspector Drawer */}
        {selectedCell && (
          <div className="p-4 bg-indigo-50/80 border-t border-indigo-200 text-xs text-indigo-950 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="font-bold text-sm text-indigo-900 flex items-center gap-2">
                <span>Rincian Perhitungan Sel:</span>
                <span className="bg-white px-2 py-0.5 rounded border border-indigo-200">
                  {selectedCell.alt.name} ({selectedCell.criterion.fullName})
                </span>
              </div>
              <div className="mt-1 text-indigo-800">
                Nilai Mentah x_ij = <span className="font-mono font-bold">{selectedCell.rawVal}</span> | Nilai Pembagi = <span className="font-mono font-bold">{selectedCell.divisor}</span> | Jenis: <span className="uppercase font-semibold">{selectedCell.criterion.type}</span>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <div className="bg-white p-2.5 rounded-lg border border-indigo-200 font-mono text-sm font-bold text-indigo-950">
                {selectedCell.criterion.type === 'benefit' ? (
                  <span>{selectedCell.rawVal} / {selectedCell.divisor} = {formatNumber(selectedCell.result, 4)}</span>
                ) : (
                  <span>{selectedCell.divisor} / {selectedCell.rawVal} = {formatNumber(selectedCell.result, 4)}</span>
                )}
              </div>
              <button
                onClick={() => setSelectedCell(null)}
                className="text-xs text-indigo-700 hover:text-indigo-900 underline font-medium cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
