import React from 'react';
import { 
  Trophy, 
  Sparkles, 
  Download, 
  Printer, 
  HelpCircle,
  CheckCircle2,
  Medal,
  Award
} from 'lucide-react';
import { Criterion, Alternative, CalculationResult } from '../types/saw';
import { formatNumber } from '../utils/sawCalculator';

interface WeightedMatrixTableProps {
  criteria: Criterion[];
  alternatives: Alternative[];
  calcResult: CalculationResult;
  onOpenExcelRef: () => void;
}

export const WeightedMatrixTable: React.FC<WeightedMatrixTableProps> = ({
  criteria,
  alternatives,
  calcResult,
  onOpenExcelRef,
}) => {
  const { weightedMatrix, finalScores, rankings, bestAlternative } = calcResult;

  // Function to export table to CSV
  const handleExportCSV = () => {
    const headers = ['Peringkat', 'Kode', 'Nama Toko Alternatif', ...criteria.map(c => `${c.fullName} (${c.weight}%)`), 'Nilai Akhir (V)'];
    const rows = rankings.map(r => [
      r.rank,
      r.alternative.code,
      `"${r.alternative.name}"`,
      ...criteria.map(c => formatNumber(r.weightedValues[c.id] || 0, 4)),
      formatNumber(r.score, 6),
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Hasil_SPK_SAW_Warung_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Info */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
            <span>Langkah 3</span>
            <span aria-hidden="true">·</span>
            <span>Matriks Terbobot &amp; Nilai Preferensi (V)</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Hasil Akhir &amp; Peringkat Rekomendasi Pemasok
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Perkalian matriks normalisasi (R) dengan bobot kriteria (W), dijumlahkan untuk memperoleh nilai preferensi (V_i).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 rounded-lg border border-slate-300 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            <span>Ekspor CSV</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 rounded-lg border border-slate-300 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span>Cetak Laporan</span>
          </button>
        </div>
      </div>

      {/* Excel Formula Banner Replication */}
      {bestAlternative && (
        <div className="p-5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-950 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider block">
                Hasil Keputusan Terbesar
              </span>
              <span className="text-lg font-black text-slate-900 tracking-tight block">
                HASIL TERBESAR ADALAH {bestAlternative.alternative.name.toUpperCase()} DENGAN NILAI = {formatNumber(bestAlternative.score, 4)}
              </span>
            </div>
          </div>

          <div className="text-xs font-mono bg-white px-3 py-1.5 rounded-md border border-indigo-200 text-indigo-900 font-semibold self-start sm:self-auto">
            {bestAlternative.code}: {bestAlternative.score.toFixed(6)}
          </div>
        </div>
      )}

      {/* Main Weighted Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-800 border-b border-slate-300">
                <th className="py-3 px-4 font-extrabold border-r border-slate-300 w-44">
                  Alternatif
                </th>
                <th className="py-3 px-3 font-bold border-r border-slate-300 text-center w-16">
                  Kode
                </th>
                {criteria.map((c) => (
                  <th key={c.id} className="py-3 px-4 font-bold text-center border-r border-slate-300">
                    <div>{c.fullName}</div>
                    <div className="text-[10px] text-slate-500 font-normal">
                      (Bobot: {c.weight}%)
                    </div>
                  </th>
                ))}
                <th className="py-3 px-4 font-extrabold text-right bg-emerald-100/70 text-emerald-950 border-r border-emerald-300 w-36">
                  Nilai Akhir (V)
                </th>
                <th className="py-3 px-3 font-extrabold text-center bg-indigo-100/70 text-indigo-950 w-24">
                  Peringkat
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-200">
              {rankings.map((item) => {
                const isWinner = item.rank === 1;

                return (
                  <tr 
                    key={item.alternative.id}
                    className={`hover:bg-slate-50 transition-colors ${
                      isWinner ? 'bg-emerald-50/50 font-medium' : ''
                    }`}
                  >
                    <td className="py-3 px-4 font-bold text-slate-900 border-r border-slate-200">
                      <div className="flex items-center gap-2">
                        {isWinner && <Trophy className="w-4 h-4 text-amber-500 shrink-0" />}
                        <span>{item.alternative.name}</span>
                      </div>
                    </td>

                    <td className="py-3 px-3 text-center font-mono font-bold text-slate-500 border-r border-slate-200">
                      {item.alternative.code}
                    </td>

                    {criteria.map((c) => {
                      const val = item.weightedValues[c.id] || 0;
                      return (
                        <td key={c.id} className="py-3 px-4 text-center font-mono border-r border-slate-200 tabular-nums">
                          {formatNumber(val, 4)}
                        </td>
                      );
                    })}

                    <td className="py-3 px-4 text-right font-mono font-black text-sm text-emerald-800 bg-emerald-50/40 border-r border-emerald-200 tabular-nums">
                      {formatNumber(item.score, 4)}
                    </td>

                    <td className="py-3 px-3 text-center">
                      <span className={`inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold ${
                        isWinner 
                          ? 'bg-emerald-600 text-white shadow-xs' 
                          : item.rank === 2
                          ? 'bg-slate-300 text-slate-800 font-bold'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {item.rank}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Formula Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">Rumus Preferensi:</span>
            <span className="font-mono bg-white px-2 py-0.5 rounded border border-slate-200">
              V_i = ∑ [ w_j × r_ij ]
            </span>
          </div>
          <div>
            Alternatif dengan nilai preferensi <span className="font-bold text-emerald-700">V_i tertinggi</span> terpilih sebagai pemasok barang terbaik warung kelontong.
          </div>
        </div>
      </div>
    </div>
  );
};
