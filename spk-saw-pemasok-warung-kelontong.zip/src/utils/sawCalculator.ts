import { Criterion, Alternative, DivisorMode, CalculationResult } from '../types/saw';

export function calculateSAW(
  criteria: Criterion[],
  alternatives: Alternative[],
  divisorMode: DivisorMode = 'sheet'
): CalculationResult {
  const divisors: Record<string, number> = {};

  // 1. Calculate Divisors (Automatically recomputes Max for Benefit and Min for Cost)
  criteria.forEach((criterion) => {
    const values = alternatives
      .map((alt) => alt.values[criterion.id] ?? 0)
      .filter((val) => !isNaN(val) && val > 0);

    if (values.length === 0) {
      divisors[criterion.id] = 1;
    } else if (criterion.type === 'benefit') {
      const dynamicMax = Math.max(...values);
      if (divisorMode === 'sheet' && typeof criterion.customDivisor === 'number') {
        // If data exceeds sheet divisor, adapt automatically to highest value
        divisors[criterion.id] = Math.max(criterion.customDivisor, dynamicMax);
      } else {
        divisors[criterion.id] = dynamicMax;
      }
    } else {
      // Cost: find minimum value
      const dynamicMin = Math.min(...values);
      if (divisorMode === 'sheet' && typeof criterion.customDivisor === 'number') {
        // If data is lower than sheet divisor, adapt automatically to lowest value
        divisors[criterion.id] = Math.min(criterion.customDivisor, dynamicMin);
      } else {
        divisors[criterion.id] = dynamicMin;
      }
    }
  });

  // Calculate sum of weights for normalized weighting
  const totalWeight = criteria.reduce((sum, c) => sum + (c.weight || 0), 0) || 100;

  // 2. Compute Normalization Matrix (R) and Weighted Matrix
  const normalizedMatrix: Record<string, Record<string, number>> = {};
  const weightedMatrix: Record<string, Record<string, number>> = {};
  const finalScores: Record<string, number> = {};

  alternatives.forEach((alt) => {
    normalizedMatrix[alt.id] = {};
    weightedMatrix[alt.id] = {};
    let totalScore = 0;

    criteria.forEach((criterion) => {
      const rawVal = alt.values[criterion.id] ?? 0;
      const divisor = divisors[criterion.id] || 1;
      let r_ij = 0;

      if (criterion.type === 'benefit') {
        // r_ij = x_ij / Max(x_j)
        r_ij = divisor !== 0 ? rawVal / divisor : 0;
      } else {
        // r_ij = Min(x_j) / x_ij
        r_ij = rawVal !== 0 ? divisor / rawVal : 0;
      }

      normalizedMatrix[alt.id][criterion.id] = r_ij;

      // w_j normalized fraction
      const normalizedW = criterion.weight / totalWeight;
      const weightedVal = normalizedW * r_ij;
      weightedMatrix[alt.id][criterion.id] = weightedVal;

      totalScore += weightedVal;
    });

    finalScores[alt.id] = totalScore;
  });

  // 3. Rank alternatives
  const sortedAlts = [...alternatives].sort((a, b) => {
    const scoreA = finalScores[a.id] ?? 0;
    const scoreB = finalScores[b.id] ?? 0;
    return scoreB - scoreA;
  });

  const rankings = sortedAlts.map((alt, index) => ({
    rank: index + 1,
    alternative: alt,
    score: finalScores[alt.id],
    normalizedValues: normalizedMatrix[alt.id] || {},
    weightedValues: weightedMatrix[alt.id] || {},
  }));

  const bestAlternative = rankings.length > 0
    ? {
        alternative: rankings[0].alternative,
        score: rankings[0].score,
        code: rankings[0].alternative.code,
      }
    : null;

  return {
    divisors,
    normalizedMatrix,
    weightedMatrix,
    finalScores,
    rankings,
    bestAlternative,
    timestamp: new Date().toLocaleTimeString('id-ID', { hour12: false }),
  };
}

export function formatNumber(val: number, decimals: number = 4): string {
  if (isNaN(val)) return '0';
  // Avoid floating point jitter
  const rounded = Number(Math.round(Number(val + 'e' + decimals)) + 'e-' + decimals);
  return rounded.toString();
}

export function formatDecimals(val: number, maxDecimals: number = 4): string {
  if (isNaN(val)) return '0';
  return Number(val.toFixed(maxDecimals)).toString();
}
