import { Criterion, Alternative } from '../types/saw';

export const DEFAULT_CRITERIA: Criterion[] = [
  {
    id: 'C1',
    name: 'Harga',
    fullName: 'C1.Harga',
    weight: 30,
    type: 'benefit',
    customDivisor: 4,
    description: 'Tingkat kompetisi harga grosir dan penawaran diskon pembelian',
  },
  {
    id: 'C2',
    name: 'Kwalitas',
    fullName: 'C2.Kwalitas',
    weight: 25,
    type: 'benefit',
    customDivisor: 4,
    description: 'Kualitas keaslian barang dagangan dan tanggal kadaluwarsa terjamin',
  },
  {
    id: 'C3',
    name: 'Jarak',
    fullName: 'C3.Jarak',
    weight: 5,
    type: 'cost',
    customDivisor: 1,
    description: 'Jarak lokasi pemasok ke warung kelontong (semakin dekat semakin baik)',
  },
  {
    id: 'C4',
    name: 'Kelengkapan',
    fullName: 'C4.Kelengkapan',
    weight: 30,
    type: 'benefit',
    customDivisor: 5,
    description: 'Ketersediaan ragam produk dan kelengkapan varian barang kebutuhan pokok',
  },
  {
    id: 'C5',
    name: 'Pelayanan',
    fullName: 'C5.Pelayanan',
    weight: 10,
    type: 'benefit',
    customDivisor: 4,
    description: 'Kecepatan pengiriman, kemudahan pemesanan, dan keramahan respon',
  },
];

export const DEFAULT_ALTERNATIVES: Alternative[] = [
  {
    id: 'A1',
    code: 'V1',
    name: 'Toko Dewi',
    values: {
      C1: 4,
      C2: 4,
      C3: 5,
      C4: 4,
      C5: 4,
    },
    note: 'Pemasok langganan lama dengan pelayanan ramah',
  },
  {
    id: 'A2',
    code: 'V2',
    name: 'Toko Pinem',
    values: {
      C1: 4,
      C2: 4,
      C3: 4,
      C4: 4,
      C5: 4,
    },
    note: 'Grosir terlengkap di area pusat pasar',
  },
  {
    id: 'A3',
    code: 'V3',
    name: 'Toko Semangat Baru',
    values: {
      C1: 3,
      C2: 3,
      C3: 3,
      C4: 3,
      C5: 4,
    },
    note: 'Pemasok baru dengan pelayanan memuaskan',
  },
  {
    id: 'A4',
    code: 'V4',
    name: 'Toko Meicin',
    values: {
      C1: 3,
      C2: 3,
      C3: 2,
      C4: 3,
      C5: 3,
    },
    note: 'Jarak dekat namun variasi produk sedang',
  },
  {
    id: 'A5',
    code: 'V5',
    name: 'Toko Siagian Jaya',
    values: {
      C1: 4,
      C2: 3,
      C3: 1,
      C4: 4,
      C5: 3,
    },
    note: 'Jarak paling dekat dengan harga sangat bersaing',
  },
];

export const PRESET_SCENARIOS = [
  {
    id: 'default',
    title: 'Data Tabel Excel Asli',
    description: 'Nilai dan bobot tepat sesuai lembar kerja referensi pengguna.',
  },
  {
    id: 'prioritas-jarak',
    title: 'Simulasi: Prioritas Pengiriman Cepat (Jarak Bobot 25%)',
    description: 'Melihat pengaruh saat ongkir/jarak menjadi pertimbangan utama.',
  },
  {
    id: 'prioritas-harga',
    title: 'Simulasi: Perang Harga (Harga Bobot 50%)',
    description: 'Fokus penghematan modal pembelian barang warung kelontong.',
  },
];
