export type CriterionType = 'benefit' | 'cost';

export interface Criterion {
  id: string; // e.g. "C1"
  name: string; // e.g. "Harga"
  fullName: string; // e.g. "C1.Harga"
  weight: number; // percentage, e.g. 30
  type: CriterionType;
  customDivisor: number; // e.g. 4 for C1, 4 for C2, 1 for C3, 5 for C4, 4 for C5
  description: string;
}

export interface Alternative {
  id: string; // e.g. "A1"
  code: string; // e.g. "V1"
  name: string; // e.g. "Toko Dewi"
  values: Record<string, number>; // criterionId -> value (e.g. { C1: 4, C2: 4, C3: 5, C4: 4, C5: 4 })
  note?: string;
}

export type DivisorMode = 'sheet' | 'dynamic'; // 'sheet' = using sheet divisors (C4=5), 'dynamic' = max(column) for benefit, min(column) for cost

export interface CalculationResult {
  divisors: Record<string, number>;
  normalizedMatrix: Record<string, Record<string, number>>; // altId -> criterionId -> r_ij
  weightedMatrix: Record<string, Record<string, number>>; // altId -> criterionId -> (w_j * r_ij)
  finalScores: Record<string, number>; // altId -> V_i
  rankings: Array<{
    rank: number;
    alternative: Alternative;
    score: number;
    normalizedValues: Record<string, number>;
    weightedValues: Record<string, number>;
  }>;
  bestAlternative: {
    alternative: Alternative;
    score: number;
    code: string;
  } | null;
  timestamp: string;
}
