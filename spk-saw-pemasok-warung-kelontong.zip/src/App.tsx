/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { AutoCalcBanner } from './components/AutoCalcBanner';
import { DashboardView } from './components/DashboardView';
import { DecisionMatrixTable } from './components/DecisionMatrixTable';
import { NormalizationMatrixTable } from './components/NormalizationMatrixTable';
import { WeightedMatrixTable } from './components/WeightedMatrixTable';
import { CriteriaManagerView } from './components/CriteriaManagerView';
import { SensitivitySimulator } from './components/SensitivitySimulator';
import { AddAlternativeModal } from './components/AddAlternativeModal';
import { ExcelReferenceModal } from './components/ExcelReferenceModal';
import { DEFAULT_CRITERIA, DEFAULT_ALTERNATIVES } from './data/defaultSawData';
import { Criterion, Alternative, DivisorMode, CalculationResult } from './types/saw';
import { calculateSAW } from './utils/sawCalculator';

export default function App() {
  const [criteria, setCriteria] = useState<Criterion[]>(() => JSON.parse(JSON.stringify(DEFAULT_CRITERIA)));
  const [alternatives, setAlternatives] = useState<Alternative[]>(() => JSON.parse(JSON.stringify(DEFAULT_ALTERNATIVES)));
  const [divisorMode, setDivisorMode] = useState<DivisorMode>('sheet');
  const [autoCalculate, setAutoCalculate] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [recalcCount, setRecalcCount] = useState<number>(1);
  const [lastUpdated, setLastUpdated] = useState<string>(() => new Date().toLocaleTimeString('id-ID', { hour12: false }));
  
  // Last edit event for live calculation demonstration
  const [lastEdit, setLastEdit] = useState<{
    altName: string;
    critName: string;
    oldVal: number;
    newVal: number;
    timestamp: string;
  } | null>(null);

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState<boolean>(false);

  // Manual calculation state snapshot when autoCalculate is OFF
  const [manualCalcSnapshot, setManualCalcSnapshot] = useState<CalculationResult | null>(null);

  // Auto-calculated Result: re-evaluates immediately when criteria, alternatives, or divisorMode change
  const dynamicCalcResult = useMemo(() => {
    return calculateSAW(criteria, alternatives, divisorMode);
  }, [criteria, alternatives, divisorMode]);

  // Actual effective result used by the UI
  const calcResult = autoCalculate ? dynamicCalcResult : (manualCalcSnapshot || dynamicCalcResult);

  // Increment recalc count on changes
  const triggerRecalcNotification = useCallback(() => {
    setRecalcCount((prev) => prev + 1);
    setLastUpdated(new Date().toLocaleTimeString('id-ID', { hour12: false }));
  }, []);

  // Update a single cell in the decision matrix
  const handleUpdateAlternativeValue = useCallback((altId: string, critId: string, val: number) => {
    let altName = '';
    let critName = '';
    let oldVal = 0;

    setAlternatives((prev) =>
      prev.map((alt) => {
        if (alt.id === altId) {
          altName = alt.name;
          oldVal = alt.values[critId] ?? 0;
          return {
            ...alt,
            values: {
              ...alt.values,
              [critId]: val,
            },
          };
        }
        return alt;
      })
    );

    const foundCrit = criteria.find(c => c.id === critId);
    critName = foundCrit ? foundCrit.fullName : critId;

    setLastEdit({
      altName: altName || 'Alternatif',
      critName,
      oldVal,
      newVal: val,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour12: false }),
    });

    triggerRecalcNotification();
  }, [criteria, triggerRecalcNotification]);

  // Update custom divisor for a criterion (sheet mode)
  const handleUpdateCustomDivisor = useCallback((critId: string, val: number) => {
    setCriteria((prev) =>
      prev.map((c) => {
        if (c.id === critId) {
          return { ...c, customDivisor: val };
        }
        return c;
      })
    );
    triggerRecalcNotification();
  }, [triggerRecalcNotification]);

  // Update criterion property (weight, type, etc)
  const handleUpdateCriterion = useCallback((id: string, updates: Partial<Criterion>) => {
    setCriteria((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          return { ...c, ...updates };
        }
        return c;
      })
    );
    triggerRecalcNotification();
  }, [triggerRecalcNotification]);

  // Normalize weights to sum exactly 100%
  const handleNormalizeWeights = useCallback(() => {
    const currentSum = criteria.reduce((sum, c) => sum + (c.weight || 0), 0);
    if (currentSum === 0) return;

    setCriteria((prev) => {
      let accumulated = 0;
      return prev.map((c, index) => {
        if (index === prev.length - 1) {
          return { ...c, weight: Math.max(0, 100 - accumulated) };
        }
        const normalized = Math.round((c.weight / currentSum) * 100);
        accumulated += normalized;
        return { ...c, weight: normalized };
      });
    });
    triggerRecalcNotification();
  }, [criteria, triggerRecalcNotification]);

  // Add new alternative
  const handleAddAlternative = useCallback((newAlt: Alternative) => {
    setAlternatives((prev) => [...prev, newAlt]);
    triggerRecalcNotification();
  }, [triggerRecalcNotification]);

  // Delete alternative
  const handleDeleteAlternative = useCallback((altId: string) => {
    setAlternatives((prev) => prev.filter((a) => a.id !== altId));
    triggerRecalcNotification();
  }, [triggerRecalcNotification]);

  // Reset to original spreadsheet data
  const handleResetData = useCallback(() => {
    setCriteria(JSON.parse(JSON.stringify(DEFAULT_CRITERIA)));
    setAlternatives(JSON.parse(JSON.stringify(DEFAULT_ALTERNATIVES)));
    setDivisorMode('sheet');
    triggerRecalcNotification();
  }, [triggerRecalcNotification]);

  // Manual recalculate trigger
  const handleManualRecalculate = useCallback(() => {
    setManualCalcSnapshot(calculateSAW(criteria, alternatives, divisorMode));
    triggerRecalcNotification();
  }, [criteria, alternatives, divisorMode, triggerRecalcNotification]);

  const toggleAutoCalculate = () => {
    setAutoCalculate((prev) => {
      const next = !prev;
      if (next) {
        setManualCalcSnapshot(null);
      } else {
        setManualCalcSnapshot(dynamicCalcResult);
      }
      return next;
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      {/* 1. Header / Navbar conforming to Top Bar Contract */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenExcelRef={() => setIsExcelModalOpen(true)}
        onResetData={handleResetData}
        autoCalculate={autoCalculate}
        toggleAutoCalculate={toggleAutoCalculate}
      />

      {/* 2. Auto-Calculation Real-Time Indicator & Divisor Controller */}
      <AutoCalcBanner
        autoCalculate={autoCalculate}
        toggleAutoCalculate={toggleAutoCalculate}
        divisorMode={divisorMode}
        setDivisorMode={(mode) => {
          setDivisorMode(mode);
          triggerRecalcNotification();
        }}
        lastUpdated={lastUpdated}
        recalcCount={recalcCount}
        onManualRecalculate={handleManualRecalculate}
      />

      {/* 3. Main Workspace Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            criteria={criteria}
            alternatives={alternatives}
            calcResult={calcResult}
            divisorMode={divisorMode}
            lastEdit={lastEdit}
            onSelectTab={setActiveTab}
            onUpdateAlternativeValue={handleUpdateAlternativeValue}
            onOpenExcelRef={() => setIsExcelModalOpen(true)}
          />
        )}

        {activeTab === 'decision' && (
          <DecisionMatrixTable
            criteria={criteria}
            alternatives={alternatives}
            divisors={calcResult.divisors}
            divisorMode={divisorMode}
            calcResult={calcResult}
            lastEdit={lastEdit}
            onUpdateValue={handleUpdateAlternativeValue}
            onUpdateCustomDivisor={handleUpdateCustomDivisor}
            onAddAlternative={() => setIsAddModalOpen(true)}
            onDeleteAlternative={handleDeleteAlternative}
            onResetData={handleResetData}
          />
        )}

        {activeTab === 'normalization' && (
          <NormalizationMatrixTable
            criteria={criteria}
            alternatives={alternatives}
            calcResult={calcResult}
            divisorMode={divisorMode}
          />
        )}

        {activeTab === 'weighted' && (
          <WeightedMatrixTable
            criteria={criteria}
            alternatives={alternatives}
            calcResult={calcResult}
            onOpenExcelRef={() => setIsExcelModalOpen(true)}
          />
        )}

        {activeTab === 'criteria' && (
          <CriteriaManagerView
            criteria={criteria}
            onUpdateCriterion={handleUpdateCriterion}
            onNormalizeWeights={handleNormalizeWeights}
            onResetCriteria={handleResetData}
          />
        )}

        {activeTab === 'simulation' && (
          <SensitivitySimulator
            criteria={criteria}
            alternatives={alternatives}
            divisorMode={divisorMode}
            currentRankings={calcResult.rankings}
          />
        )}
      </main>

      {/* 4. Modals */}
      <AddAlternativeModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        criteria={criteria}
        existingAlternativesCount={alternatives.length}
        onAdd={handleAddAlternative}
      />

      <ExcelReferenceModal
        isOpen={isExcelModalOpen}
        onClose={() => setIsExcelModalOpen(false)}
      />

      {/* 5. Clean Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-4 px-4 sm:px-6 lg:px-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            Sistem Pendukung Keputusan (SPK) SAW · Penentuan Pemasok Barang Warung Kelontong
          </div>
          <div className="flex items-center gap-3">
            <span>Formula Terintegrasi Real-Time</span>
            <span>·</span>
            <span>Berpedoman Tabel Referensi</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
